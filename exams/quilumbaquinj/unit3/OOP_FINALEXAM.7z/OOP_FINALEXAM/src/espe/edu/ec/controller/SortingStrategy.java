package espe.edu.ec.controller;

/**
 *
 * @author QUILUMBAQUIN JAIRO,STEVEN POZO DCC0-ESPE: CODEX++
 */
abstract class SortingStrategy {
    
    abstract int[] sort(int number[]);
    
}
